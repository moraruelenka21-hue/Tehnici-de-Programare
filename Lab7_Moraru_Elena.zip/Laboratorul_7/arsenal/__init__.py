"""Utilitare Python."""

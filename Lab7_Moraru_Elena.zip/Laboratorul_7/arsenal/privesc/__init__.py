"""Analiza fisierelor de intrare."""
